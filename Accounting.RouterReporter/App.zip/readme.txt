﻿sc.exe create RouterReporter binPath="c:\rr\RouterReporter.exe" start="auto" depend= "RaMgmtSvc"
sc.exe delete RouterReporter