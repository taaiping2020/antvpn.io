﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Accounting.RouterReporter
{
    public class Meta
    {
        public string name { get; set; }
        public string[] users { get; set; }
        public DateTime timestamp { get; set; }
    }
}
